package com.capgemini.laps.bean;

public class CustomerBean {
	private String customerId;
	private String customerName;
	private String phoneNumber;
	private String address;
	private double loanAmount;
	public String getCustomerrId() {
		return customerId;
	}
	public void setCustomerrId(String customerrId) {
		this.customerId = customerrId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public  void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	

}
